/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoedd;

/**
 *
 * @author ile1
 */
public class TablaHash {
    
    public TablaHash(int capacidad){
        
    }
    
    private ListaEnlazada<EntradaHash>[] tabla;
    private int capacidad;
    private int numElementos;
    
    public Estacion buscar(String clave){
        
        return null;
    }
    
    public void insertar(String clave, Estacion estacion){
        
    }

public boolean eliminar(String clave){
    int indice = funcionHash(clave);
    ListaEnlazada<EntradaHash> lista = tabla[indice];
    NodoLista<EntradaHash> actual = lista.getCabeza();
    
    while (actual != null){
        if(actual.getContenido().getClave().equalsIgnoreCase(clave)){
            lista.eliminar(actual.getContenido());
            numElementos--;
            return true; 
        }
        actual = actual.getSiguiente();
    }
    return false;
}

    private int funcionHash(String clave) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
