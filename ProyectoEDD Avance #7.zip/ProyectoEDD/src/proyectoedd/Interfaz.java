/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package proyectoedd;

import javax.swing.JOptionPane;
import java.awt.BorderLayout;

/**
 *
 * @author Usuario
 */
public class Interfaz extends javax.swing.JPanel {

    private TablaHash tablaHash;
    private GrafoPonderado grafo;
    private PanelMapa graficoRed;
    private Object proyectoedd;
  
  public Interfaz(TablaHash tablaHash, GrafoPonderado grafo){
      initComponents();
      
      this.tablaHash = tablaHash;
      this.grafo = grafo;
      this.graficoRed = new PanelMapa(this.grafo);
      this.panelMapaContenedor.setLayout(new java.awt.BorderLayout());
      this.panelMapaContenedor.add(this.graficoRed, java.awt.BorderLayout.CENTER);
      this.panelMapaContenedor.revalidate();
      this.panelMapaContenedor.repaint();
        
}
    public void refrescarCanvas(){
        if (this.panelMapaContenedor != null) { 
            // Le decimos a Java que trate este panel específicamente como tu PanelMapa
            ((proyectoedd.PanelMapa) this.panelMapaContenedor).setGrafo(this.grafo); 
            this.panelMapaContenedor.repaint(); 
        }
        
        if(panelMapaContenedor == null) return;
        panelMapaContenedor.removeAll();
        
        PanelMapa graficoRed = new PanelMapa(this.grafo);
        graficoRed.setSize(panelMapaContenedor.getSize());
        
        panelMapaContenedor.add(graficoRed);
        panelMapaContenedor.revalidate();
        panelMapaContenedor.repaint();  
    }
    
    public void actualizarDatos(TablaHash nuevaTabla, GrafoPonderado nuevoGrafo) {
        this.tablaHash = nuevaTabla;
        this.grafo = nuevoGrafo;
        refrescarCanvas();
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        BuscarEst = new javax.swing.JButton();
        NuevaEst = new javax.swing.JButton();
        NuevaConexion = new javax.swing.JButton();
        ModTiempo = new javax.swing.JButton();
        panelMapaContenedor = new proyectoedd.PanelMapa();
        btnSubredes = new javax.swing.JButton();
        btnRutaOptima = new javax.swing.JButton();
        btnVerHubs = new javax.swing.JButton();

        setLayout(new java.awt.BorderLayout());

        BuscarEst.setText("Buscar Estación");
        BuscarEst.addActionListener(this::BuscarEstActionPerformed);

        NuevaEst.setText("Nueva Estación");
        NuevaEst.addActionListener(this::NuevaEstActionPerformed);

        NuevaConexion.setText("Nueva Conexión");
        NuevaConexion.addActionListener(this::NuevaConexionActionPerformed);

        ModTiempo.setText("Modificar Tiempo");
        ModTiempo.addActionListener(this::ModTiempoActionPerformed);

        javax.swing.GroupLayout panelMapaContenedorLayout = new javax.swing.GroupLayout(panelMapaContenedor);
        panelMapaContenedor.setLayout(panelMapaContenedorLayout);
        panelMapaContenedorLayout.setHorizontalGroup(
            panelMapaContenedorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 765, Short.MAX_VALUE)
        );
        panelMapaContenedorLayout.setVerticalGroup(
            panelMapaContenedorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 352, Short.MAX_VALUE)
        );

        btnSubredes.setText("Ver Subredes");
        btnSubredes.addActionListener(this::btnSubredesActionPerformed);

        btnRutaOptima.setText("Calcular Ruta Óptima");
        btnRutaOptima.addActionListener(this::btnRutaOptimaActionPerformed);

        btnVerHubs.setText("Ver Hubs Principal");
        btnVerHubs.addActionListener(this::btnVerHubsActionPerformed);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(89, 89, 89)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(btnSubredes)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnRutaOptima)
                                .addGap(194, 194, 194)
                                .addComponent(btnVerHubs))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(196, 196, 196)
                                .addComponent(NuevaEst)
                                .addGap(101, 101, 101)
                                .addComponent(NuevaConexion))
                            .addComponent(panelMapaContenedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(90, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(BuscarEst)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(ModTiempo)
                        .addGap(137, 137, 137))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(48, 48, 48)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(NuevaEst)
                    .addComponent(NuevaConexion))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BuscarEst)
                    .addComponent(ModTiempo))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 48, Short.MAX_VALUE)
                .addComponent(panelMapaContenedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(47, 47, 47)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSubredes)
                    .addComponent(btnRutaOptima)
                    .addComponent(btnVerHubs))
                .addGap(37, 37, 37))
        );

        add(jPanel1, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents
    
    private void btnCalcularRutaActionPerformed(java.awt.event.ActionEvent evt) {                                                
        if (this.grafo == null) {
            JOptionPane.showMessageDialog(this, "Debe cargar un archivo primero.");
            return;
        }
        String origen = JOptionPane.showInputDialog(this, "Ingrese ID de la estación de origen:");
        String destino = JOptionPane.showInputDialog(this, "Ingrese ID de la estación de destino:");
        
        if (origen != null && destino != null) {
            String resultado = this.grafo.rutaMasRapidaDijkstra(origen.toUpperCase(), destino.toUpperCase());
            JOptionPane.showMessageDialog(this, resultado, "Ruta Más Rápida", JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    private void btnVerHubActionPerformed(java.awt.event.ActionEvent evt){
        if(this.grafo == null){
            JOptionPane.showConfirmDialog(this, "Debe cargar un archivo primero.");
            return;
        }
        String resultado = this.grafo.identificarHubs();
        JOptionPane.showMessageDialog(this, resultado, "Hubs de transferencia", JOptionPane.INFORMATION_MESSAGE);
    }
    
    
    private void ModTiempoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ModTiempoActionPerformed
        String auxOrig = JOptionPane.showInputDialog(this, "Estación de origen:");
        String auxDest = JOptionPane.showInputDialog(this, "Estación de detino:");
        String txtNewTime = JOptionPane.showInputDialog(this, "Nuevo tiempo (min):");

        if (auxOrig != null && auxDest != null && txtNewTime != null){
            try{
                int nuevoTiempo = Integer.parseInt(txtNewTime.trim());
                Vertice vOrigen = this.grafo.buscarVertice(auxOrig.trim());
                Vertice vDestino = this.grafo.buscarVertice(auxDest.trim());

                if (vOrigen != null && vDestino != null){
                    boolean flagCambio = false;

                    //Actualizar de Origen a Destino
                    NodoLista itO = vOrigen.getAdyacentes().getCabeza();
                    while(itO != null){
                        Arista link = (Arista) itO.getContenido();
                        if (link.getIdDestino().equals(auxDest.trim())){
                            link.setTiempo(nuevoTiempo);
                            flagCambio = true;
                        }
                        itO = itO.getSiguiente();
                    }

                    //Actualizar de Desitno a Origen
                    NodoLista itD = vDestino.getAdyacentes().getCabeza();
                    while(itD != null){
                        Arista linkV = (Arista) itD.getContenido();
                        if (linkV.getIdDestino().equals(auxOrig.trim())){
                            linkV.setTiempo(nuevoTiempo);
                        }
                        itD = itD.getSiguiente();
                    }

                    if(flagCambio){
                        JOptionPane.showMessageDialog(this, "Tiempo actualizado correctamente.");
                    } else {
                        JOptionPane.showMessageDialog(this, "No se encontró una conexión directa entre estas estaciones.", "Aviso", JOptionPane.WARNING_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Una o ambas estaciones no existen.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException errorNums){
                JOptionPane.showMessageDialog(this, "El tiempo debe ser un número entero.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }//GEN-LAST:event_ModTiempoActionPerformed

    private void NuevaConexionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NuevaConexionActionPerformed
        String inputOrig = JOptionPane.showInputDialog(this, "Nombre de estación de origen:");
        String inputDest = JOptionPane.showInputDialog(this, "Nombre de estación de destino:");
        String minText = JOptionPane.showInputDialog(this, "Tiempo de recorrido (minutos):");

        if  (inputOrig != null && inputDest != null && minText != null){
            try{
                int minDuracion = Integer.parseInt(minText.trim());
                inputOrig = inputOrig.trim();
                inputDest = inputDest.trim();

                if (this.tablaHash.buscar(inputOrig) == null){
                    this.tablaHash.insertar(inputOrig, new Estacion(inputOrig, inputOrig, "Línea 1", "General", 0));
                }
                if (this.tablaHash.buscar(inputDest) == null){
                    this.tablaHash.insertar(inputDest, new Estacion(inputDest, inputDest, "Línea 1", "General", 0));
                }

                this.grafo.agregarAristaNoDirigida(inputOrig, inputDest, minDuracion);
                JOptionPane.showMessageDialog(this, "Conexión creada exitosamente.");
            } catch (NumberFormatException exTipeo){
                JOptionPane.showMessageDialog(this, "El tiempo debe ser un número entero.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }//GEN-LAST:event_NuevaConexionActionPerformed

    private void NuevaEstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NuevaEstActionPerformed
        String nuevoId = JOptionPane.showInputDialog(this, "ID de la nueva estación (Ej. PRO): ");
        if (nuevoId == null || nuevoId.trim().isEmpty()) return;

        nuevoId = nuevoId.trim();
        if(this.tablaHash.buscar(nuevoId) == null){
            String nombreLargo = JOptionPane.showInputDialog(this, "Nombre completo: ");

            Estacion estDinamica = new Estacion(nuevoId, nombreLargo, "Línea 1", "General", 0);
            this.tablaHash.insertar(nuevoId, estDinamica);

            int posX = (int) (Math.random() * 300)+50;
            int posY = (int) (Math.random() * 300)+50;

            this.grafo.agregarVertice(nuevoId, posX, posY);
            refrescarCanvas();

            JOptionPane.showMessageDialog(this, "Estación agregada.");
        }else{
            JOptionPane.showMessageDialog(this, "ID se encuentra registrado.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_NuevaEstActionPerformed

    private void BuscarEstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BuscarEstActionPerformed
        String inptId = JOptionPane.showInputDialog(this, "Escriba el ID de la estación (Ej. ALT): ");

        if(inptId != null && !inptId.trim().isEmpty()){
            Estacion nodoEncontrado = this.tablaHash.buscar(inptId.trim());

            if(nodoEncontrado != null){
                String msjInfo = "Estación Encontrada: " + nodoEncontrado.getNombre()
                + "\nLínea: " + nodoEncontrado.getLineaMetro();
                JOptionPane.showMessageDialog(this, "Esa estación no existe.", "Fallo", JOptionPane.ERROR_MESSAGE);
            }
        }
    }//GEN-LAST:event_BuscarEstActionPerformed

    private void btnSubredesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSubredesActionPerformed
        if(this.grafo == null || this.grafo.obtenerCantidadVertices() == 0){
            javax.swing.JOptionPane.showMessageDialog(this,
                    "Debe cargar el archivo de grafo antes de consultar las subredes.",
                    "Advertencia", javax.swing.JOptionPane.WARNING_MESSAGE);
            return;
    }
        
        String resultado = this.grafo.mostrarSubredes();
        javax.swing.JOptionPane.showMessageDialog(this, 
                resultado,
                "Reporte de Subredes (DFS/BFS)",
                javax.swing.JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_btnSubredesActionPerformed

    private void btnRutaOptimaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRutaOptimaActionPerformed
        if(this.grafo == null || this.grafo.obtenerCantidadVertices() == 0){
            javax.swing.JOptionPane.showMessageDialog(this, 
                    "Debe cargar el archivo de grafo antes de calcular una ruta.",
                    "Advertencia", javax.swing.JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        String origen = javax.swing.JOptionPane.showInputDialog(this,
                "Ingrese el ID de la estación de Origen (ej. PRO):",
                "Ruta Óptima - Dijkstra", javax.swing.JOptionPane.QUESTION_MESSAGE);
        
        if(origen == null || origen.trim().isEmpty()) return;
        
        String destino = javax.swing.JOptionPane.showInputDialog(this,
                "Ingrese el ID de la estación de Destino (ej. CAP):",
                "Ruta Óptima - Dijkstra", javax.swing.JOptionPane.QUESTION_MESSAGE);
        
        if (destino == null || destino.trim().isEmpty()) return;
        
        String resultado = this.grafo.rutaMasRapidaDijkstra(origen.trim().toUpperCase(), destino.trim().toUpperCase());
        javax.swing.JOptionPane.showMessageDialog(this, 
                resultado,
                "Resultado de Ruta Óptima",
                javax.swing.JOptionPane.INFORMATION_MESSAGE);
        
    }//GEN-LAST:event_btnRutaOptimaActionPerformed

    private void btnVerHubsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVerHubsActionPerformed
        if(this.grafo == null || this.grafo.obtenerCantidadVertices() == 0){
             javax.swing.JOptionPane.showMessageDialog(this, 
                    "Debe cargar el grafo antes de consultar los Hubs.",
                    "Advertencia", javax.swing.JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        String resultado = this.grafo.identificarHubs();
        javax.swing.JOptionPane.showMessageDialog(this, 
                resultado,
                "Hubs de Transferencia (Centralidad de Grado)",
                javax.swing.JOptionPane.INFORMATION_MESSAGE);
         
    }//GEN-LAST:event_btnVerHubsActionPerformed
   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BuscarEst;
    private javax.swing.JButton ModTiempo;
    private javax.swing.JButton NuevaConexion;
    private javax.swing.JButton NuevaEst;
    private javax.swing.JButton btnRutaOptima;
    private javax.swing.JButton btnSubredes;
    private javax.swing.JButton btnVerHubs;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel panelMapaContenedor;
    // End of variables declaration//GEN-END:variables
}
