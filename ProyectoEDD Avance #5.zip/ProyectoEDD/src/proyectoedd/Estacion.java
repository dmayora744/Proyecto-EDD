/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoedd;

/**
 *
 * @author ile1
 */
public class Estacion {

//agrupando strings para ahorrar líneas
private String id, nombreEst, lineaM, zonaUbic;
private int cantCapacidad;

public Estacion(String id, String nombre, String lineaMetro, String zona, int capacidad){
    this.id = id;
    this.nombreEst = nombre;
    this.lineaM = lineaMetro;
    this.zonaUbic = zona;
    this.cantCapacidad = capacidad;    
}

public String getNombre(){
    return nombreEst;
}

public int getCapacidad(){
    return cantCapacidad;
}

public String getID(){
    return id;
}

public String getZona(){
    return zonaUbic;
}

public String getLinea(){
    return lineaM;
}

public String getLineaMetro(){
    return lineaM;
}

    String getZonaUbicacion() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    String getCapacidadMax() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
