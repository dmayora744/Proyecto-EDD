/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package proyectoedd;

import javax.swing.JOptionPane;
import java.awt.BorderLayout;

/**
 *
 * @author Usuario
 */
public class Interfaz extends javax.swing.JPanel {

    private TablaHash tablaHash;
    private GrafoPonderado grafo;
    private PanelMapa graficoRed;
    private Object proyectoedd;
  
  public Interfaz(TablaHash tablaHash, GrafoPonderado grafo){
      initComponents();
      
      this.tablaHash = tablaHash;
      this.grafo = grafo;
      this.graficoRed = new PanelMapa(this.grafo);
      this.panelMapaContenedor.setLayout(new java.awt.BorderLayout());
      this.panelMapaContenedor.add(this.graficoRed, java.awt.BorderLayout.CENTER);
      this.panelMapaContenedor.revalidate();
      this.panelMapaContenedor.repaint();
        
}
    public void refrescarCanvas(){
        if (this.panelMapaContenedor != null) { 
            // Le decimos a Java que trate este panel específicamente como tu PanelMapa
            ((proyectoedd.PanelMapa) this.panelMapaContenedor).setGrafo(this.grafo); 
            this.panelMapaContenedor.repaint(); 
        }
        
        if(panelMapaContenedor == null) return;
        panelMapaContenedor.removeAll();
        
        PanelMapa graficoRed = new PanelMapa(this.grafo);
        graficoRed.setSize(panelMapaContenedor.getSize());
        
        panelMapaContenedor.add(graficoRed);
        panelMapaContenedor.revalidate();
        panelMapaContenedor.repaint();  
    }
    
    public void actualizarDatos(TablaHash nuevaTabla, GrafoPonderado nuevoGrafo) {
        this.tablaHash = nuevaTabla;
        this.grafo = nuevoGrafo;
        refrescarCanvas();
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        BuscarEst = new javax.swing.JButton();
        NuevaEst = new javax.swing.JButton();
        NuevaConexion = new javax.swing.JButton();
        ModTiempo = new javax.swing.JButton();
        panelMapaContenedor = new proyectoedd.PanelMapa();

        setLayout(new java.awt.BorderLayout());

        BuscarEst.setText("Buscar Estación");
        BuscarEst.addActionListener(this::BuscarEstActionPerformed);

        NuevaEst.setText("Nueva Estación");
        NuevaEst.addActionListener(this::NuevaEstActionPerformed);

        NuevaConexion.setText("Nueva Conexión");
        NuevaConexion.addActionListener(this::NuevaConexionActionPerformed);

        ModTiempo.setText("Modificar Tiempo");
        ModTiempo.addActionListener(this::ModTiempoActionPerformed);

        javax.swing.GroupLayout panelMapaContenedorLayout = new javax.swing.GroupLayout(panelMapaContenedor);
        panelMapaContenedor.setLayout(panelMapaContenedorLayout);
        panelMapaContenedorLayout.setHorizontalGroup(
            panelMapaContenedorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        panelMapaContenedorLayout.setVerticalGroup(
            panelMapaContenedorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 396, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(89, 89, 89)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(panelMapaContenedor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(BuscarEst)
                        .addGap(84, 84, 84)
                        .addComponent(NuevaEst)
                        .addGap(101, 101, 101)
                        .addComponent(NuevaConexion)
                        .addGap(68, 68, 68)
                        .addComponent(ModTiempo)))
                .addContainerGap(137, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(48, 48, 48)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BuscarEst)
                    .addComponent(NuevaEst)
                    .addComponent(NuevaConexion)
                    .addComponent(ModTiempo))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 77, Short.MAX_VALUE)
                .addComponent(panelMapaContenedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(63, 63, 63))
        );

        add(jPanel1, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    private void ModTiempoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ModTiempoActionPerformed
        String auxOrig = JOptionPane.showInputDialog(this, "Estación de origen:");
        String auxDest = JOptionPane.showInputDialog(this, "Estación de detino:");
        String txtNewTime = JOptionPane.showInputDialog(this, "Nuevo tiempo (min):");

        if (auxOrig != null && auxDest != null && txtNewTime != null){
            try{
                int nuevoTiempo = Integer.parseInt(txtNewTime.trim());
                Vertice vOrigen = this.grafo.buscarVertice(auxOrig.trim());
                Vertice vDestino = this.grafo.buscarVertice(auxDest.trim());

                if (vOrigen != null && vDestino != null){
                    boolean flagCambio = false;

                    //Actualizar de Origen a Destino
                    NodoLista itO = vOrigen.getAdyacentes().getCabeza();
                    while(itO != null){
                        Arista link = (Arista) itO.getContenido();
                        if (link.getIdDestino().equals(auxDest.trim())){
                            link.setTiempo(nuevoTiempo);
                            flagCambio = true;
                        }
                        itO = itO.getSiguiente();
                    }

                    //Actualizar de Desitno a Origen
                    NodoLista itD = vDestino.getAdyacentes().getCabeza();
                    while(itD != null){
                        Arista linkV = (Arista) itD.getContenido();
                        if (linkV.getIdDestino().equals(auxOrig.trim())){
                            linkV.setTiempo(nuevoTiempo);
                        }
                        itD = itD.getSiguiente();
                    }

                    if(flagCambio){
                        JOptionPane.showMessageDialog(this, "Tiempo actualizado correctamente.");
                    } else {
                        JOptionPane.showMessageDialog(this, "No se encontró una conexión directa entre estas estaciones.", "Aviso", JOptionPane.WARNING_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Una o ambas estaciones no existen.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException errorNums){
                JOptionPane.showMessageDialog(this, "El tiempo debe ser un número entero.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }//GEN-LAST:event_ModTiempoActionPerformed

    private void NuevaConexionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NuevaConexionActionPerformed
        String inputOrig = JOptionPane.showInputDialog(this, "Nombre de estación de origen:");
        String inputDest = JOptionPane.showInputDialog(this, "Nombre de estación de destino:");
        String minText = JOptionPane.showInputDialog(this, "Tiempo de recorrido (minutos):");

        if  (inputOrig != null && inputDest != null && minText != null){
            try{
                int minDuracion = Integer.parseInt(minText.trim());
                inputOrig = inputOrig.trim();
                inputDest = inputDest.trim();

                if (this.tablaHash.buscar(inputOrig) == null){
                    this.tablaHash.insertar(inputOrig, new Estacion(inputOrig, inputOrig, "Línea 1", "General", 0));
                }
                if (this.tablaHash.buscar(inputDest) == null){
                    this.tablaHash.insertar(inputDest, new Estacion(inputDest, inputDest, "Línea 1", "General", 0));
                }

                this.grafo.agregarAristaNoDirigida(inputOrig, inputDest, minDuracion);
                JOptionPane.showMessageDialog(this, "Conexión creada exitosamente.");
            } catch (NumberFormatException exTipeo){
                JOptionPane.showMessageDialog(this, "El tiempo debe ser un número entero.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }//GEN-LAST:event_NuevaConexionActionPerformed

    private void NuevaEstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NuevaEstActionPerformed
        String nuevoId = JOptionPane.showInputDialog(this, "ID de la nueva estación (Ej. PRO): ");
        if (nuevoId == null || nuevoId.trim().isEmpty()) return;

        nuevoId = nuevoId.trim();
        if(this.tablaHash.buscar(nuevoId) == null){
            String nombreLargo = JOptionPane.showInputDialog(this, "Nombre completo: ");

            Estacion estDinamica = new Estacion(nuevoId, nombreLargo, "Línea 1", "General", 0);
            this.tablaHash.insertar(nuevoId, estDinamica);

            int posX = (int) (Math.random() * 300)+50;
            int posY = (int) (Math.random() * 300)+50;

            this.grafo.agregarVertice(nuevoId, posX, posY);
            refrescarCanvas();

            JOptionPane.showMessageDialog(this, "Estación agregada.");
        }else{
            JOptionPane.showMessageDialog(this, "ID se encuentra registrado.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_NuevaEstActionPerformed

    private void BuscarEstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BuscarEstActionPerformed
        String inptId = JOptionPane.showInputDialog(this, "Escriba el ID de la estación (Ej. ALT): ");

        if(inptId != null && !inptId.trim().isEmpty()){
            Estacion nodoEncontrado = this.tablaHash.buscar(inptId.trim());

            if(nodoEncontrado != null){
                String msjInfo = "Estación Encontrada: " + nodoEncontrado.getNombre()
                + "\nLínea: " + nodoEncontrado.getLineaMetro();
                JOptionPane.showMessageDialog(this, "Esa estación no existe.", "Fallo", JOptionPane.ERROR_MESSAGE);
            }
        }
    }//GEN-LAST:event_BuscarEstActionPerformed
   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BuscarEst;
    private javax.swing.JButton ModTiempo;
    private javax.swing.JButton NuevaConexion;
    private javax.swing.JButton NuevaEst;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel panelMapaContenedor;
    // End of variables declaration//GEN-END:variables
}
