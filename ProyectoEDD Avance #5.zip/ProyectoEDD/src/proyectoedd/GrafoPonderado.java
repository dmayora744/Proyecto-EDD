/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoedd;

/**
 *
 * @author ile1
 */
public class GrafoPonderado {

    private ListaEnlazada listaVertices;
    
    public GrafoPonderado(){
        this.listaVertices = new ListaEnlazada();
    }
    
    public Vertice buscarVertice(String idBuscado){
        NodoLista nodoActual = listaVertices.getCabeza();
        
        while (nodoActual != null){
            Vertice objV = (Vertice) nodoActual.getContenido();
            if (objV.getIdEstacion().equals(idBuscado)){
                return objV;
            }
            nodoActual = nodoActual.getSiguiente();
        }
        return null;
    }
    
    public void agregarVertice(String idUnico, int ejeX, int ejeY){
        if(buscarVertice(idUnico) == null){
        Vertice vertNuevo = new Vertice(idUnico);
        listaVertices.agregar(vertNuevo);
    }
    }
 
    
    public void agregarAristaNoDirigida(String idOrigen, String idDest, int minDeViaje){
        Vertice nodoOrig = buscarVertice(idOrigen);
        Vertice nodoDest = buscarVertice(idDest);
        
        if (nodoOrig == null){
            nodoOrig = new Vertice(idOrigen);
            listaVertices.agregar(nodoOrig);
        }
        if (nodoDest == null){
            nodoDest = new Vertice(idDest);
            listaVertices.agregar(nodoDest);
        }
        
        nodoOrig.getAdyacentes().agregar(new Arista(idDest,minDeViaje));
        nodoDest.getAdyacentes().agregar(new Arista(idOrigen, minDeViaje));
    }
    public Object getVertices(){
        return listaVertices;
    }
   
}
