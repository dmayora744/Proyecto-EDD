/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoedd;

import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JPanel;

public class PanelMapa extends JPanel{
    private GrafoPonderado grafo;
    
    public PanelMapa() {
    this.setBackground(java.awt.Color.WHITE);
}
    
    public PanelMapa(GrafoPonderado grafo){
        this.setBackground(java.awt.Color.WHITE);   
    }
    
    public void setGrafo(GrafoPonderado grafo) {
        this.grafo = grafo;
        this.repaint();
    }
    
@Override
    protected void paintComponent(Graphics g){
        
        super.paintComponent(g);
        
        if(grafo == null) {
            System.out.println("ESTADO: El grafo es null, no se dibuja nada.");
            return;
        }
        
        System.out.println("ESTADO: Grafo recibido. Iniciando dibujo de nodos...");
        
        NodoLista actualV = ((ListaEnlazada) grafo.getVertices()).getCabeza();
        
        while (actualV != null){
            Vertice vOrigen = (Vertice) actualV.getContenido();
            NodoLista actualA = vOrigen.getAdyacentes().getCabeza();
            
            while (actualA != null){
                Arista arista = (Arista) actualA.getContenido();
                
                //Búsqueda del vértice destino para saber sus coordenadas X e Y
                Vertice vDestino = grafo.buscarVertice(arista.getIdDestino());
                
                if(vDestino != null){
                    g.setColor(Color.BLACK);
                    //Se suman 15 para que la línea salga del centro del círculo
                    g.drawLine(vOrigen.getPosX() + 15, vOrigen.getPosY() + 15, vDestino.getPosX() + 15, vDestino.getPosY() + 15);
                    
                    //Dibujo de texto del tiempo en el medio de la línea
                    int medioX = (vOrigen.getPosX() + vDestino.getPosX())/2;
                    int medioY = (vOrigen.getPosY() + vDestino.getPosY())/2;
                    
                    g.setColor(Color.RED);
                    g.drawString(arista.getTiempoMinutos() + "min", medioX, medioY);
                }
                actualA = actualA.getSiguiente();
            }
            actualV = actualV.getSiguiente();
        }
        
        //Dibujo de las estaciones (Vértices) encima de las líneas
        actualV = ((ListaEnlazada) grafo.getVertices()).getCabeza();
        
        while (actualV != null){
            Vertice v = (Vertice) actualV.getContenido();
            
            //Dibujo del círculo del nodo
            g.setColor(Color.BLUE);
            g.fillOval(v.getPosX(), v.getPosY(), 30, 30);
            
            //Dibujo del ID de la estación justo arriba del círculo
            g.setColor(Color.BLACK);
            g.drawString(v.getIdEstacion(), v.getPosX(), v.getPosY() - 5);
            
            actualV = actualV.getSiguiente();
        }
    }
}
