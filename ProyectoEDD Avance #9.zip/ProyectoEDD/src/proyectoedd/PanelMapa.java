/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoedd;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import javax.swing.JPanel;

public class PanelMapa extends JPanel {

    private GrafoPonderado grafo;

    public PanelMapa() {
        setBackground(new Color(240, 242, 245));
    }

    public PanelMapa(GrafoPonderado grafo) {
        this();
        this.grafo = grafo;
    }

    public void setGrafo(GrafoPonderado grafo) {
        this.grafo = grafo;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        if (this.grafo == null) return;

        int n = this.grafo.obtenerCantidadVertices();
        if (n == 0) return;

        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int w = getWidth();
        int h = getHeight();
        if (w <= 0) w = 750;
        if (h <= 0) h = 400;

        int centroX = w / 2;
        int centroY = h / 2;
        int radioX = Math.max(50, (int) (w * 0.38));
        int radioY = Math.max(50, (int) (h * 0.38));

        // Arreglos locales para almacenar posiciones dinámicas sin tocar Vertice.java
        int[] posX = new int[n];
        int[] posY = new int[n];
        String[] ids = new String[n];

        // 1. Calcular las coordenadas en círculo/elipse para los N nodos
        NodoLista actual = this.grafo.listaVertices.getCabeza();
        int idx = 0;
        while (actual != null && idx < n) {
            Vertice v = (Vertice) actual.getContenido();
            if (v != null) {
                ids[idx] = v.getIdEstacion();
                double angulo = 2.0 * Math.PI * idx / n;
                posX[idx] = (int) (centroX + radioX * Math.cos(angulo));
                posY[idx] = (int) (centroY + radioY * Math.sin(angulo));
            }
            actual = actual.getSiguiente();
            idx++;
        }

        // 2. Dibujar las conexiones (líneas y tiempos)
        actual = this.grafo.listaVertices.getCabeza();
        idx = 0;
        while (actual != null && idx < n) {
            Vertice v = (Vertice) actual.getContenido();
            if (v != null && v.getAdyacentes() != null) {
                NodoLista aristaAct = v.getAdyacentes().getCabeza();
                while (aristaAct != null) {
                    Arista a = (Arista) aristaAct.getContenido();
                    if (a != null) {
                        String idDestino = a.getIdDestino();
                        int destIdx = -1;
                        for (int k = 0; k < n; k++) {
                            if (ids[k] != null && ids[k].equals(idDestino)) {
                                destIdx = k;
                                break;
                            }
                        }
                        if (destIdx != -1) {
                            // Línea de conexión
                            g2.setColor(new Color(100, 110, 120));
                            g2.drawLine(posX[idx], posY[idx], posX[destIdx], posY[destIdx]);

                            // Tiempo en rojo
                            g2.setColor(new Color(200, 30, 30));
                            int midX = (posX[idx] + posX[destIdx]) / 2;
                            int midY = (posY[idx] + posY[destIdx]) / 2;
                            g2.drawString(a.getTiempoMinutos() + "m", midX, midY);
                        }
                    }
                    aristaAct = aristaAct.getSiguiente();
                }
            }
            actual = actual.getSiguiente();
            idx++;
        }

        // 3. Dibujar las estaciones (círculos azules con texto blanco)
        for (int i = 0; i < n; i++) {
            if (ids[i] == null) continue;
            int x = posX[i];
            int y = posY[i];

            // Círculo azul
            g2.setColor(new Color(41, 128, 185));
            g2.fillOval(x - 16, y - 16, 32, 32);

            // Borde blanco
            g2.setColor(Color.WHITE);
            g2.drawOval(x - 16, y - 16, 32, 32);

            // ID de la estación
            g2.setColor(Color.WHITE);
            g2.drawString(ids[i], x - 12, y + 4);
        }
    }
}
