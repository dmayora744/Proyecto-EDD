/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoedd;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import javax.swing.JPanel;

public class PanelMapa extends JPanel {

    private GrafoPonderado grafo;

    public PanelMapa() {
        setBackground(new Color(240, 242, 245));
    }

    public PanelMapa(GrafoPonderado grafo) {
        this();
        this.grafo = grafo;
    }

    public void setGrafo(GrafoPonderado grafo) {
        this.grafo = grafo;
        repaint();
    }
    
    private int[] obtenerPosicionEsquema(String id){
        if (id == null) return null;
        switch(id.trim().toUpperCase()){
            //Carril 0 (Superior - Línea 3)
            case "RIN": return new int[]{5, 0};
            case "MDC": return new int[]{6, 0};
            case "COC": return new int[]{7, 0};
            case "VAL": return new int[]{8, 0};
            case "BAN": return new int[]{9, 0};
            case "SYM": return new int[]{10, 0};
            case "CUD": return new int[]{11, 0};
            
            //Carril 1 (Eje Central - Línea 1)
            case "PRO": return new int[]{0, 1};
            case "PER": return new int[]{1, 1};
            case "PZA": return new int[]{2, 1};
            case "GAT": return new int[]{3, 1};
            case "AGU": return new int[]{4, 1};
            case "CAÑ": return new int[]{5, 1};
            case "SIL": return new int[]{6, 1};
            case "CAP": return new int[]{7, 1};
            case "LAO": return new int[]{8, 1};
            case "PAR": return new int[]{9, 1};
            case "BEL": return new int[]{10, 1};
            case "COL": return new int[]{11, 1};
            case "PZA_VZLA": return new int[]{12, 1};
            case "SAB": return new int[]{13, 1};
            case "CHA": return new int[]{14, 1};
            case "CHA_CAO": return new int[]{15, 1};
            case "ALT": return new int[]{16, 1};
            case "MIR": return new int[]{17, 1};
            case "DOS_C": return new int[]{18, 1};
            case "LOS_C": return new int[]{19, 1};
            case "PET": return new int[]{20, 1};
            case "PAL": return new int[]{21, 1};
            
            //Carril 2 (Medio-Inferior - Línea 4)
            case "ZUM": return new int[]{13, 2};
            case "PAR_C": return new int[]{14, 2};
            case "TEAT": return new int[]{15, 2};
            case "CAP_L4": return new int[]{16, 2};
            
            //Carril 3 (Inferior - Línea 2)
            case "ZOO": return new int[]{8, 3};
            case "CAR": return new int[]{9, 3};
            case "MAM": return new int[]{10, 3};
            case "ANT": return new int[]{11, 3};
            case "YAR": return new int[]{12, 3};
            case "LA_P": return new int[]{13, 3};
            case "ART": return new int[]{14, 3};
            case "MAT": return new int[]{15, 3};
            
            default: return null;
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        if (this.grafo == null) return;

        int n = this.grafo.obtenerCantidadVertices();
        if (n == 0) return;

        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int w = getWidth() > 0 ? getWidth() : 996;
        int h = getHeight() > 0 ? getHeight() : 569;
        
        String[] ids = new String[n];
        int[] grados = new int[n];
        int[] posX = new int [n];
        int[] posY = new int[n];
        
        // 1. Calcular las coordenadas en círculo/elipse para los N nodos
        NodoLista actual = this.grafo.listaVertices.getCabeza();
        int idx = 0;
        int coincidenciasEsquema = 0;
        
        while (actual != null && idx < n) {
            Vertice v = (Vertice) actual.getContenido();
            if (v != null) {
                ids[idx] = v.getIdEstacion();
                if (obtenerPosicionEsquema(ids[idx]) != null){
                    coincidenciasEsquema++;
                }
                int deg = 0;
                if(v.getAdyacentes() != null){
                    NodoLista a = v.getAdyacentes().getCabeza();
                    while (a != null){
                        deg++;
                        a = a.getSiguiente();
                    }
                }
                grados[idx] = deg;
            }
            actual = actual.getSiguiente();
            idx++;
        }
        
        int margenX = 45;
        int anchoUtil = Math.max(200, w - margenX * 2);
        
        if(coincidenciasEsquema >= 3){
            
            int[] filasY = {
                (int) (h * 0.24), //Catrril 0 (Línea 3)
                (int) (h * 0.44), //Catrril 1 (Línea 1 principal)
                (int) (h * 0.66), //Catrril 2 (Línea 4)
                (int) (h * 0.86), //Catrril 3 (Línea 2)
            };
            double pasoX = anchoUtil / 21.0;
            int extraCount = 0;
            
            for (int i = 0; i < n; i++){
                int[] coord = obtenerPosicionEsquema(ids[i]);
                if(coord != null){
                    posX[i] = (int)(margenX + coord[0] * pasoX);
                    posY[i] = filasY[coord[1]];
                } else {
                    //Estaciones aisladas que van ordenadas arriba
                    posX[i] = margenX + 60 + (extraCount * 75) % Math.max(120, anchoUtil - 80);
                    posY[i] = (int) (h * 0.09) + ((extraCount * 75) / Math.max(120, anchoUtil - 80)) * 35;
                    extraCount++;
                }
            }
        } else {
            int cols = Math.max(4, (int) Math.ceil(Math.sqrt(n * 1.6)));
            int rows = (int) Math.ceil((double) n / cols);
            double pasoX = anchoUtil / (double) Math.max(1, cols - 1);
            double pasoY = (h - 100.0) / Math.max(1, rows);
            
            for (int i = 0; i < n; i++){
                int r = i / cols;
                int c = i % cols;
                posX[i] = (int) (margenX + c * pasoX);
                posY[i] = (int) (60 + r * pasoY);
            }   
        }

        // Conexiones (líneas y tiempos)
        g2.setFont(new Font("SansSerif", Font.BOLD, 9));
        actual = this.grafo.listaVertices.getCabeza();
        idx = 0;
        while (actual != null && idx < n) {
            Vertice v = (Vertice) actual.getContenido();
            if (v != null && v.getAdyacentes() != null) {
                NodoLista aristaAct = v.getAdyacentes().getCabeza();
                while (aristaAct != null) {
                    Arista a = (Arista) aristaAct.getContenido();
                    if (a != null) {
                        String idDestino = a.getIdDestino();
                        int destIdx = -1;
                        for (int k = 0; k < n; k++) {
                            if (ids[k] != null && ids[k].equals(idDestino)) {
                                destIdx = k;
                                break;
                            }
                        }
                        if (destIdx != -1 && idx < destIdx) {
                            // Línea de conexión
                            g2.setStroke(new BasicStroke(1.5f));
                            g2.setColor(new Color(120, 132, 145));
                            g2.drawLine(posX[idx], posY[idx], posX[destIdx], posY[destIdx]);

                            g2.setColor(new Color(195, 35, 35));
                            int midX = (posX[idx] + posX[destIdx]) / 2;
                            int midY = (posY[idx] + posY[destIdx]) / 2;
                            g2.drawString(a.getTiempoMinutos() + "m", midX + 2, midY - 4);
                        }
                    }
                    aristaAct = aristaAct.getSiguiente();
                }
            }
            actual = actual.getSiguiente();
            idx++;
        }

        // Estaciones (círculos azules con texto blanco)
        g2.setFont(new Font("SansSerif", Font.BOLD, 10));
        FontMetrics fm = g2.getFontMetrics();
        
        for (int i = 0; i < n; i++) {
            if (ids[i] == null) continue;
            int x = posX[i];
            int y = posY[i];
            int radio = (grados[i] >= 3) ? 16 : 13;

            // Círculo azul
            g2.setColor(new Color(79, 163, 227));
            g2.fillOval(x - radio, y - radio, radio * 2, radio * 2);

            // Borde blanco
            g2.setStroke(new BasicStroke(1.5f));
            g2.setColor(new Color(33, 97, 140));
            g2.drawOval(x - radio, y - radio, radio * 2, radio * 2);

            g2.setColor(Color.WHITE);
            int textW = fm.stringWidth(ids[i]);
            int textH = fm.getAscent();
            g2.drawString(ids[i], x - textW / 2, y + textH / 2 - 2);
        }
    }
}
