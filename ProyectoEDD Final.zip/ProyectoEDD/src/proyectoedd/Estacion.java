/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoedd;

/**
 *
 * @author ile1
 */
public class Estacion {

//agrupando strings para ahorrar líneas
private String id, nombreEst, lineaM, zonaUbic;
private int cantCapacidad;
    
    public Estacion(String id, String nombre, String lineaMetro, String zona, int capacidad){
        this.id = id;
        this.nombreEst = nombre;
        this.lineaM = lineaMetro;
        this.zonaUbic = zona;
        this.cantCapacidad = capacidad;
    }

public String getNombre(){
    return this.nombreEst;
}

public String getID(){
    return this.id;
}

public String getZona(){
    return this.zonaUbic;
}

public String getLinea(){
    return this.lineaM;
}

public String getLineaMetro(){
    return this.lineaM;
}

public String getZonaUbicacion(){
    return this.zonaUbic;
}

public int getCapacidad(){
    return cantCapacidad;
}

public int getCapacidadMax(){
    return this.cantCapacidad;
}
    
}
