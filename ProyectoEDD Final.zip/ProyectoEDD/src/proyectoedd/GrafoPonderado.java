/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoedd;

/**
 *
 * @author ile1
 */
public class GrafoPonderado {

    ListaEnlazada listaVertices;
    
    public GrafoPonderado(){
        this.listaVertices = new ListaEnlazada();
    }
    
    public int obtenerCantidadVertices(){
        int contador = 0;
        
        NodoLista actual = this.listaVertices.getCabeza();
        while (actual != null){
            contador++;
            actual = actual.getSiguiente();
        }
        return contador;
    }
    
    public String mostrarSubredes(){
        int n = obtenerCantidadVertices();
        if(n==0) return "El grafo está vacío. Cargue un archivo primero.";
        
        String[] ids = new String [n];
        boolean[] visitados = new boolean[n];
        NodoLista actual = this.listaVertices.getCabeza();
        int idx = 0;
        
        while(actual != null){
            Vertice v = (Vertice) actual.getContenido();
            ids[idx] = v.getIdEstacion();
            idx++;
            actual = actual.getSiguiente();
        }
        
        StringBuilder resultado = new StringBuilder("--- REPORTE DE SUBREDES ---\n");
        int numeroSubred = 1;
        
        for (int i = 0; i < n; i++){
            if (!visitados[i]){
                resultado.append("Subred ").append(numeroSubred).append(": ");
                dfsAuxUI(ids[i], ids, visitados, resultado);
                resultado.append("\n");
                numeroSubred++;
            }
        }
        return resultado.toString();
    }
    
    private void dfsAuxUI(String idVertice, String[] ids, boolean[] visitados, StringBuilder res){
        int indice = -1;
        for (int i = 0; i < ids.length; i++){
            if(ids[i].equals(idVertice)){ indice = i; break; }
        }
        if (indice != -1 && !visitados[indice]){
            visitados[indice] = true;
            res.append(idVertice).append(" ");
            
            Vertice v = buscarVertice(idVertice);
            if(v != null){
                NodoLista aristaActual = v.getAdyacentes().getCabeza();
                while(aristaActual != null){
                    Arista a = (Arista) aristaActual.getContenido();
                    dfsAuxUI(a.getIdDestino(), ids, visitados, res);
                    aristaActual = aristaActual.getSiguiente();
                }
            }
        }  
    }
    
    public String rutaMasRapidaDijkstra(String idOrigen, String idDestino){
        int n = obtenerCantidadVertices();
        if (n == 0) return "El grafo está vacío.";
        
        String[] ids = new String[n];
        int[] distancias = new int[n];
        String[] previos = new String[n];
        boolean[] visitados = new boolean[n];
        int infinito = 999999;
        
        NodoLista actual = this.listaVertices.getCabeza();
        int idx = 0;
        int idxOrigen = -1;
        
        while (actual != null){
            Vertice v = (Vertice) actual.getContenido();
            ids[idx] = v.getIdEstacion();
            distancias[idx] = infinito;
            if (ids[idx].equals(idOrigen)) idxOrigen = idx;
            idx++;
            actual = actual.getSiguiente();
        }
        
        if (idxOrigen == -1) return "Estación de origen no encontrada en el grafo.";
        
        distancias[idxOrigen] = 0;
        
        for(int i = 0; i < n; i++) {
            int minDist = infinito;
            int u = -1;
            for (int j=0; j < n; j++){
                if (!visitados[j] && distancias[j] <= minDist){
                    minDist = distancias[j];
                    u = j;
                }
            }
            if (u == -1 || distancias[u] == infinito) break;
            visitados[u] = true;
            
            Vertice v = buscarVertice(ids[u]);
            NodoLista aristaActual = v.getAdyacentes().getCabeza();
            while (aristaActual != null){
                Arista a = (Arista) aristaActual.getContenido();
                String idVecino = a.getIdDestino();
                int peso = a.getTiempoMinutos();
                
                int vIdx = -1;
                for (int k = 0; k < n; k++){
                    if (ids[k].equals(idVecino)) { vIdx = k; break; }
                }
                
                if (vIdx != -1 && !visitados[vIdx] && distancias [u] + peso < distancias[vIdx]){
                    distancias[vIdx] = distancias[u] + peso;
                    previos[vIdx] = ids[u];
                }
                aristaActual = aristaActual.getSiguiente();
            }
        }
        int idxDestino = -1;
        for (int i = 0; i < n; i++) {
            if (ids[i].equals(idDestino)) { idxDestino = i; break; }
        }
        
        if (idxDestino == -1 || distancias[idxDestino] == infinito) {
            return "No hay ruta disponible entre " + idOrigen + " y " + idDestino;
        }
        
        String ruta = idDestino;
        String paso = previos[idxDestino];
        while (paso != null) {
            ruta = paso + " -> " + ruta;
            int pIdx = -1;
            for (int k = 0; k < n; k++) { if (ids[k].equals(paso)) { pIdx = k; break; } }
            paso = (pIdx != -1) ? previos[pIdx] : null;
        }
        
        return "--- RUTA MÁS RÁPIDA ---\n" +
               "Tiempo total: " + distancias[idxDestino] + " minutos\n" +
               "Camino: " + ruta;
    }      
    
    public String identificarHubs(){
       if (obtenerCantidadVertices() == 0) return "El grafo está vacío.";
       
       NodoLista actual = this.listaVertices.getCabeza();
       String hubPrincipal = "";
       int maxConexiones = -1;
       
       while (actual != null){
           Vertice v = (Vertice) actual.getContenido();
           int contadorConexiones = 0;
           NodoLista aristaActual = v.getAdyacentes().getCabeza();
           while (aristaActual != null){
               contadorConexiones++;
               aristaActual = aristaActual.getSiguiente();
           }
           
           if (contadorConexiones > maxConexiones){
               maxConexiones = contadorConexiones;
               hubPrincipal = v.getIdEstacion();
           }
           actual = actual.getSiguiente();
       }
       return "-> EL HUB PRINCIPAL ES: " + hubPrincipal + " con " + maxConexiones + " conexiones directas.";
    }
    
    public Vertice buscarVertice(String idBuscado){
        NodoLista nodoActual = listaVertices.getCabeza();
        
        while (nodoActual != null){
            Vertice objV = (Vertice) nodoActual.getContenido();
            if (objV.getIdEstacion().equals(idBuscado)){
                return objV;
            }
            nodoActual = nodoActual.getSiguiente();
        }
        return null;
    }
    
    public void agregarVertice(String idUnico, int ejeX, int ejeY){
        if(buscarVertice(idUnico) == null){
        Vertice vertNuevo = new Vertice(idUnico);
        listaVertices.agregar(vertNuevo);
    }
    }
 
    
    public void agregarAristaNoDirigida(String idOrigen, String idDest, int minDeViaje){
        Vertice nodoOrig = buscarVertice(idOrigen);
        Vertice nodoDest = buscarVertice(idDest);
        
        if (nodoOrig == null){
            nodoOrig = new Vertice(idOrigen);
            listaVertices.agregar(nodoOrig);
        }
        if (nodoDest == null){
            nodoDest = new Vertice(idDest);
            listaVertices.agregar(nodoDest);
        }
        
        nodoOrig.getAdyacentes().agregar(new Arista(idDest,minDeViaje));
        nodoDest.getAdyacentes().agregar(new Arista(idOrigen, minDeViaje));
    }
    public Object getVertices(){
        return listaVertices;
    }
   
}
