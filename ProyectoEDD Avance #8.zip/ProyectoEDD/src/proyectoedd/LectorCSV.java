/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoedd;

import java.io.File;
import java.io.BufferedReader;
import java.io.FileReader;
import javax.swing.JOptionPane;

public class LectorCSV {
    
    
    public static boolean cargarArchivo(File archivo, TablaHash tablaHash, GrafoPonderado grafo){
        try(BufferedReader br = new BufferedReader(new FileReader(archivo))){
            String linea;

            while((linea = br.readLine()) != null){
                linea = linea.trim();
                if(linea.isEmpty()) continue;
                
                if(linea.startsWith("ID_Estacion") || linea.startsWith("Estacion_Origen") || linea.contains("Tiempo_Traslado") || linea.contains("Nombre_Estacion")){
                    continue;
                }
                
                String[] partes = linea.split(",");
                
                if (partes.length == 3){
                    String origen = partes[0].trim();
                    String destino = partes[1].trim();
                    int tiempo = Integer.parseInt(partes[2].trim());
                    
                    if(tablaHash.buscar(origen) == null){
                        tablaHash.insertar(origen, new Estacion(origen, origen, "Línea 1", "General", 0));    
                    }
                    if(tablaHash.buscar(destino) == null){
                        tablaHash.insertar(destino, new Estacion(destino, destino, "Línea 1", "General", 0)); 
                    }
                    
                    if(grafo.buscarVertice(origen) == null){
                        int rX = (int) (Math.random() * 500) + 60;
                        int rY = (int) (Math.random() * 300) + 50;
                        grafo.agregarVertice(origen, rX, rY);
                    }
                    if(grafo.buscarVertice(destino) == null){
                        int rX = (int) (Math.random() * 500) + 60;
                        int rY = (int) (Math.random() * 300) + 50;
                        grafo.agregarVertice(destino, rX, rY);
                }
                    grafo.agregarAristaNoDirigida(origen, destino, tiempo);
            }
                else if (partes.length == 5){
                    String id = partes[0].trim();
                    String nombre = partes[1].trim();
                    String lineaMetro = partes[2].trim();
                    String zona = partes[3].trim();
                    int capacidad = Integer.parseInt(partes[4].trim());
                    
                    Estacion e = new Estacion(id, nombre, lineaMetro, zona, capacidad);
                    tablaHash.insertar(id, e);
                    
                    int randomX = (int) (Math.random() * 500) + 60;
                    int randomY = (int) (Math.random() * 300) + 50;
                    
                    if(grafo.buscarVertice(id) == null){
                        grafo.agregarVertice(id, randomX, randomY);
                    }
                }
            } 
            return true;
        } catch (Exception ex){
            JOptionPane.showMessageDialog(null, "Error al procesar el archivo CSV: " + ex.getMessage(), "Error de lectura", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
}
            
