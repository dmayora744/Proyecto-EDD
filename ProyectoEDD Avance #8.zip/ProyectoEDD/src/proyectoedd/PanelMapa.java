/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoedd;

import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JPanel;

public class PanelMapa extends JPanel {

    private GrafoPonderado grafo; 
    
    public PanelMapa(GrafoPonderado grafo) {
        this.grafo = grafo;
    }

    public PanelMapa() {
    }

    // Método crucial para recibir el grafo desde la interfaz
    public void setGrafo(GrafoPonderado grafo) {
        this.grafo = grafo;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (this.grafo == null || this.grafo.obtenerCantidadVertices() == 0) return;

        // 1. Dibujar las conexiones (líneas)
        NodoLista actual = this.grafo.listaVertices.getCabeza();
        while (actual != null) {
            Vertice v = (Vertice) actual.getContenido();
            NodoLista aristaActual = v.getAdyacentes().getCabeza(); // Usamos el getter que corregimos
            
            while (aristaActual != null) {
                Arista a = (Arista) aristaActual.getContenido();
                Vertice destino = this.grafo.buscarVertice(a.getIdDestino());
                
                if (destino != null) {
                    g.setColor(Color.BLACK);
                    g.drawLine(v.getPosX(), v.getPosY(), destino.getPosX(), destino.getPosY());
                    
                    // Dibujar el tiempo a la mitad de la línea
                    int midX = (v.getPosX() + destino.getPosX()) / 2;
                    int midY = (v.getPosY() + destino.getPosY()) / 2;
                    g.setColor(Color.RED);
                    g.drawString(a.getTiempoMinutos() + " min", midX, midY);
                }
                aristaActual = aristaActual.getSiguiente();
            }
            actual = actual.getSiguiente();
        }

        // 2. Dibujar las estaciones (círculos) por encima de las líneas
        actual = this.grafo.listaVertices.getCabeza();
        while (actual != null) {
            Vertice v = (Vertice) actual.getContenido();
            g.setColor(Color.BLUE);
            g.fillOval(v.getPosX() - 15, v.getPosY() - 15, 30, 30);
            
            g.setColor(Color.WHITE); // Texto en blanco para que resalte
            g.drawString(v.getIdEstacion(), v.getPosX() - 10, v.getPosY() + 5);
            
            actual = actual.getSiguiente();
        }
    }
}
